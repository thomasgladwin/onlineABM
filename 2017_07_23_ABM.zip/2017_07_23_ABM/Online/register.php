<?php
	include('header.php');
?>

<!doctype html>

<html>
<head>
	<title>Introduction</title>
	<style>
		body {
			font-family: Arial
		}
		span {
			margin-top: 0%;
			margin-right: 2%;
			background: white;
			max-width: 80%;
			display: inline-block;
		}
	</style>
</head>

<body>
<?php
	echo '<h1>Online Information Brochure '.$studyName.'</h1>';
?>
<p>It is important to carefully read the following information before starting the experiment.</p>

<h1>Aim of the experiment</h1>
<p>The experiment is aimed at further understanding automatic attentional processes.</p>

<h1>Procedure and instructions</h1>
<p>The experiment consists of multiple sessions. You will fill in questionnaires and perform tasks. Note that you will<strong>repeat</strong> some of the questionnaires and tasks: This is not an error but part of the experimental design!</p>
<p>If you register to participate, you will immediately be sent an email to perform the first session. After you complete each session, an email will be prepared to be sent at the planned time.</p>
<p>In the tasks, please pay attention to the instructions that appear at the start of each task and before each block. We provide the basic instructions here, and you can refer back to them if necessary. In the spatial visual attention task, you will indicate via a left (F-key) and right (J-key) button press whether a &lt;&lt; or &gt;&gt; symbol appears on the screen.</p>
<img src='fj.JPG'>
<p>You will also see various other stimuli, which you do not need to respond to. <strong>Important:</strong> some stimuli may be disturbing to you. You could see alcoholic, threatening or disgusting pictures. If you expect such pictures to be unacceptably disturbing, please do not do the experiment. You can also stop at any time.</p>
<p>The sessions clearly indicate when they are complete.</p>

<h1>Voluntariness</h1>
<p>If you decide not to participate, or to stop participating during the experiment at any time, this will not have any negative consequences. You may also retract your permission to use any of your data and have it destroyed if you communicate this within 24 hours of deciding to withdraw from the experiment.</p>
<p>By clicking on the button at the bottom of this page, you indicate your informed consent to participate in this experiment. This would usually be given via signature: Clicking on the button serves the same purpose in this online format.</p>

<h1>Insurance</h1>
<p>The current study does not have any special risks and there is therefore no insurance.</p>

<h1>Confidentiality</h1>
<p>Your data can be used in scientific publications. Your anonymity is guaranteed.</p>
<p>However, if the experimenters feel that your questionnaire responses warrant serious concern for your wellbeing, they may decide to have someone such as a student psychologist or counsellor contact you, solely in your own interests.</p>

<h1>Reward</h1>
<p>Completetion of the whole experiment is necessary for any agreed-on reward. Partial completion will not be rewarded except under exceptional circumstances.</p>

<h1>Further information</h1>
<p>The responsbile researchers can be contacted for further information.</p>

<h1>Data</h1>
<p>Make sure you do not incur costs for data traffic; these will not be reimbursed.</p>
<p>Note that depending on the internet connection it may take some time for tasks to load.</p>

<div style="padding:2%">

<h1>Declaration of the researchers</h1>
<p>I have provided information on the study. I have communicated my availability for any further questions.</p>
<p><?php echo $researcher_name;?>, 23 July 2017.</p>
<p>Contact email: <?php echo $researcher_email;?></p>

<h1>Declaration participant</h1>
<?php
	$_GET['completed'] = 0;
	$_GET['trainingTime'] = 0;
	$_GET['email0'] = 0;
	$_GET['sn'] = 0;
	echo '<form id = "IntroForm" action = "register2.php'.addGET(1).'" method = "post">';
?>
	<p>Your email address: <input type="text" name="email0" size="64">
	<p>At what time would you like to receive invitations? 
	<select name="trainingTime">
		<option value="01:00">01:00</option>
		<option value="02:00">02:00</option>
		<option value="03:00">03:00</option>
		<option value="04:00">04:00</option>
		<option value="05:00">05:00</option>
		<option value="06:00">06:00</option>
		<option value="07:00">07:00</option>
		<option value="08:00" selected>08:00</option>
		<option value="09:00">09:00</option>
		<option value="10:00">10:00</option>
		<option value="11:00">11:00</option>
		<option value="12:00">12:00</option>
		<option value="13:00">13:00</option>
		<option value="14:00">14:00</option>
		<option value="15:00">15:00</option>
		<option value="16:00">16:00</option>
		<option value="17:00">17:00</option>
		<option value="18:00">18:00</option>
		<option value="19:00">19:00</option>
		<option value="20:00">20:00</option>
		<option value="21:00">21:00</option>
		<option value="22:00">22:00</option>
		<option value="23:00">23:00</option>
		<option value="24:00">24:00</option>
	</select>
	<p><input type="submit" value="By clicking on this button I confiorm the following. I have read and understood the information and give consent for participating in this study and for the use of the data. I retain the right to withdraw this permission without providing a reason. I retain the right to stop participating at any time." style="white-space: normal; width: 50%">
</form>

</div>

</body>

</html>
