<?php
	include('header.php');
	$_GET['email0'] = filter_var($_POST["email0"], FILTER_SANITIZE_EMAIL);
	$_GET['trainingTime'] = $_POST["trainingTime"];
	
	// Email
	// Define the message to be sent. Each line should be separated with \n
	$message = "Dear participant,\n\nThank you for enrolling in the study!\n\n
	You can continue with the first session by clicking on the link below. It is improtant to complete each session as soon as possible after receiving the invitation. If you wait too long, the following invitation could arrive an extra day later: In this case, please continue with the task as soon as you receive the delayed invitation. Any unexpected problems? Please contact the researcher.\n\n";
	$message = $message."Please use Mozilla Firefox as your browser.\n\n";
	$message = $message."\nhttps://www.tegladwin.com/Test/".$studyDir."/Online/index.php".addGET(1)."\n\n";
	$message = $message."Regards,\n\n".$researcher_name."\n";

	require_once $_SERVER["DOCUMENT_ROOT"].'/Common/swiftmailer-5.x/lib/classes/Swift.php';
	Swift::registerAutoload();
	require_once $_SERVER["DOCUMENT_ROOT"]."/Common/swiftmailer-5.x/lib/swift_init.php";

	//echo '1';

	$transport = Swift_SmtpTransport::newInstance('smtp.gmail.com', 587, 'tls');
	$transport->setUsername($researcher_email);
	$transport->setPassword($researcher_email_password);

	//echo '2';

	$mailer = Swift_Mailer::newInstance($transport);

	//echo '3';

	$messageSwift = Swift_Message::newInstance();
	$messageSwift->setSubject('Invitation to '.$studyName);
	$messageSwift->setFrom(array($researcher_email => $researcher_name));
	$messageSwift->setTo(array(trim($_GET['email0'])));
	$messageSwift->setBody($message, 'text/plain');

	//echo '4';

	$result = $mailer->send($messageSwift);
	
	if ($result == 1) {
		echo '<h3>Registration succeeded</h3><p>Thank you for registering. You will receive an invitation with the link for the first session: Please perform this immediately or as soon as possible. If you do not receive the email, please check your spam filter and check whether the email address was entered correctly: '.$_GET['email0'].'. You can now close this tab.';
	} else {
		echo '<h3>An error occurred.</h3><p>Please check whether your email was correct: '.$_GET['email0'].'. If the problem persists, please contact the researcher.';
	}
?>
