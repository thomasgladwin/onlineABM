<?php
	include('header.php');
	
	testGET();
?>

<!doctype html>

<html>
<head>
	<title>Session</title>
	<style>
		body {
			font-family: Arial
		}
		span {
			margin-top: 0%;
			margin-right: 2%;
			background: white;
			max-width: 80%;
			display: inline-block;
		}
	</style>
</head>

<body>
<?php
	echo '<h1>'.$studyName.'</h1>';
?>

Thank you for participating in this session!

<?php
	echo '<form id = "IntroForm" action = "index_part2.php'.addGET($_GET['sn']).'" method = "post">';
?>
	<input type="submit" value="Click here to continue">
</form>

</div>

</body>

</html>
