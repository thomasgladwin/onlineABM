<?php 
	include('taskParams.php');

	$subjectName = $_POST['fileNameSubject'];
	$sessionRand = 0;
	
	$fileNameSubject = preg_replace('/[^0-9a-zA-Z]/i','', $subjectName);

	// POSTed variables
	$passCode = $_POST['passCode'];
	$fileNameBase = "data".$_POST['fileNameBase'];
	$taskIndex = $_POST['taskIndex'];
	$fileName = 'results/'.$fileNameBase."_".$fileNameSubject.".txt";
	$saveString = $_POST['saveString'];
	$saveString = "".$saveString; // For escape characters

	// Damage mitigation caused by logged-in user hijacking session to write nonsense data.
	// Check for max length of saveString
	if (strlen($saveString) > $maxStringLengthAllowed) {
		die();
	}
	// Check for filesize
	if (file_exists($fileName)) {
		$filesize0 = filesize($fileName);
		if ($filesize0 != FALSE) {
			if ($filesize0 > 1024 * 1024 * $maxFileSizeAllowed) {
				die();
			}
		}
	}

	if (strcmp($passCode, $saveDataPassCode) == 0) { // Very insecure check that the call comes from my JavaScript unless someone is making an effort to spoof and has been given log-in access as a subject.
		// Create lineText to save
		$infoLine = $subjectName."_".$_SERVER['REMOTE_ADDR']."_".time()."_".date('Y-m-d-H:i:s')."_".$_SERVER['HTTP_USER_AGENT']."_".$taskIndex."_:)_";
		$lineText = $infoLine.$saveString;
		// Encrypt lineText
		/*
		$key = pack('H*', $encryptionKey);
		$iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC);
		$iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
		$ciphertext = mcrypt_encrypt(MCRYPT_RIJNDAEL_128, $key, $lineText, MCRYPT_MODE_CBC, $iv);
		$ciphertext = $iv . $ciphertext;
		$ciphertext_base64 = base64_encode($ciphertext);
		*/
		
		// Open a file in write mode
		$fp = fopen($fileName, "a");
		fwrite($fp, $lineText."\n");	
		//fwrite($fp, $ciphertext_base64."\n");
		fclose($fp);
		echo 'E';
		chmod($fileName, 0600);
	} else {
		echo "F";
	}
?>
