<?php
	function addGET($sn) {
		$getstr = '?';
		$getstr = $getstr.'username='.$_GET['username'];
		$getstr = $getstr.'&completed='.$_GET['completed'];
		$getstr = $getstr.'&trainingTime='.$_GET['trainingTime'];
		$getstr = $getstr.'&loginsrc='.$_GET['loginsrc'];
		$getstr = $getstr.'&email0='.$_GET['email0'];
		$getstr = $getstr.'&sn='.$sn;
		$pw = generate_password($_GET['username'].$_GET['completed'].$sn);
		$getstr = $getstr.'&pw='.$pw;
		
		/*
		echo '<br>var_dump In addGET:<br>';
		var_dump($_GET);
		echo '<br>END var_dump In addGET:<br>';
		$_GET['pw'] = $pw;
		$_GET['sn'] = $sn;
		echo '<p>Test='.testGET().'</p>';
		*/
		
		return $getstr;
	}
	
	function testGET() {
		/*
		echo '<br>var_dump In testGET:<br>';
		var_dump($_GET);
		echo '<br>END var_dump In testGET:<br>';
		
		echo 'GET vars = '.$_GET['username'].$_GET['completed'].$_GET['sn'].'<br>';
		echo 'pw = '.$_GET['pw'].'<br>';
		*/
		if (test_password($_GET['username'].$_GET['completed'].$_GET['sn'], $_GET['pw']) != 1) {
			echo '<p>Please log in via the provided email link and continue through the experiment as instructed. Please check with your contact person (thomas.gladwin@gmail.com) if you still have problems.</p>';
			die();
		}
	}
?>
