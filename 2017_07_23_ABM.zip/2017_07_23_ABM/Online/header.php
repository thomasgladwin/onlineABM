<?php 
	include('taskParams.php');
	include('passfunc.php');
	include('getfunc.php');
	
	echo '<script>';
	echo 'var subjectCode = "'.$_GET['username'].'";';
	echo '</script>';	
?>
