<?php
	include('header.php');

	// Prepare unencryption
	$key = pack('H*', $encryptionKey);
	$iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC);
    $iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);

	// Run through all files in dir
	foreach (glob("resultsToDecrypt/encr*.txt") as $fileName) {
		echo $fileName.'<br>';
		$fp = fopen($fileName, "r");
		$path_parts = pathinfo($fileName);
		$fp_out = fopen("decrypted_results/".$path_parts['basename'], "w");
		while (!feof($fp)) {
			// Read line encrypted at saving
			$ciphertext_base64 = fgets($fp);
			//echo "<p>Encrypted: ".$ciphertext_base64;
			if (strlen($ciphertext_base64) == 0) {
				$plaintext_dec = "";
			} else {
				// Decrypt
				$ciphertext_dec = base64_decode($ciphertext_base64);
				$iv_dec = substr($ciphertext_dec, 0, $iv_size);
				$ciphertext_dec = substr($ciphertext_dec, $iv_size);
				$plaintext_dec = mcrypt_decrypt(MCRYPT_RIJNDAEL_128, $key, $ciphertext_dec, MCRYPT_MODE_CBC, $iv_dec);
				$plaintext_dec = rtrim($plaintext_dec, "\0");
			}
			//echo '<br>Decrypted: '.$plaintext_dec;
			// Write to plain text file
			fwrite($fp_out, $plaintext_dec."\n");
		}
		fclose($fp_out);
		fclose($fp);
	}
	
?>
