<?php
	include('header.php');
?>

<!doctype html>

<html>
<head>
	<title>Questionnaires</title>
	<script src = "jsfiles/Task/basicHelperFuncs.js"></script>
	<?php
		$subdir0 = 'Q_EN';
		echo '<script src = "jsfiles/Q/templateQ.js"></script>';
		echo '<script src = "jsfiles/Q/templateQPic.js"></script>';
		echo '<script src = "jsfiles/'.$subdir0.'/demographics.js"></script>';
		echo '<script src = "jsfiles/'.$subdir0.'/adhoc.js"></script>';
		echo '<script src = "jsfiles/'.$subdir0.'/evalStim.js"></script>';
		echo '<script src = "jsfiles/Q/questionnaireManagerObj.js"></script>';
	?>
	<style>
		body {
			font-family: Arial
		}
		span {
			margin-top: 0%;
			margin-right: 2%;
			background: white;
			max-width: 80%;
			display: inline-block;
		}
	</style>
</head>

<body>
	<?php
		if ($_GET['sn'] >= $NSessions) {
			$_GET['completed'] = 1;
			echo '<form id = "Qform" action = "end.php'.addGET($_GET['sn']).'" method = "post">';
		} else {
			echo '<form id = "Qform" action = "tasks.php'.addGET($_GET['sn']).'" method = "post">';
		}
	?>
	</form>
</body>

<script>
	var questionnaireManager = new QuestionnaireManagerObj();
	var formNode = document.getElementById("Qform");

	<?php
		if ($_GET['sn'] == 1) {
			echo 'var qArray = [demoQ, adhocQ, evalQ_Intro, evalQ_Neutral, evalQ_Rage];';
			echo 'qArray.shuffle(qArray.length - 2, qArray.length - 1);';
		} elseif ($_GET['sn'] == $NSessions - 1) {
			echo 'var qArray = [evalQ_Intro, evalQ_Neutral, evalQ_Rage];';
			echo 'qArray.shuffle(qArray.length - 2, qArray.length - 1);';
		} else { // FUp, sesion 7
			echo 'var qArray = [adhocQ];';
		}
	?>

	questionnaireManager.init(formNode, qArray, subjectCode);

</script>

</html>
