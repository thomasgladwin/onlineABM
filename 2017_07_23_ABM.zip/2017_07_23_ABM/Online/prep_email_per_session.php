<?php 

	date_default_timezone_set('Europe/Amsterdam');

	$email0 = filter_var($_GET['email0'], FILTER_SANITIZE_EMAIL);
	$trainingTime = $_GET['trainingTime'];
	$TrTi = substr($trainingTime, 0, 2) + 0;
	$username = $_GET['username'];

	$nextsn = $_GET['sn'] + 1;

	if ($nextsn <= $NSessions) {
		echo '<h3>Next invitation email</h3>';
		for ($sn = $nextsn; $sn <= $nextsn; $sn++) {

			// Day step
			$dstep = 0;
			if ($sn < $NSessions) {
				$dstep = 1; // 
			} else {
				$dstep = $final_dstep; // 
			}

			$today = getdate();

			$date_for_mail = mktime($TrTi, 0, 0, $today['mon'], $today['mday'] + $dstep, $today['year']);

			echo 'Email planned for: '.date('Y-m-d H:i', $date_for_mail).'. <br>';

			$date_for_mail = $date_for_mail - 60; // 1 minute buffer for cron job

			// POSTed variables
			$fileNameBase = "mailon_".$date_for_mail."_".rand().rand()."_".$sn;
			$fileName = 'mails/'.$fileNameBase.".txt";
			$saveString = $email0."_".$username."_".$trainingTime."_".$_GET['loginsrc'];

			// Damage mitigation caused by logged-in user hijacking session to write nonsense data.
			// Check for max length of saveString
			$maxStringLengthAllowed = 100000; // $_SESSION['MSLA'];
			if (strlen($saveString) > $maxStringLengthAllowed) {
				die();
			}
			// Check for filesize
			$maxFileSizeAllowed = 200; // $_SESSION['MFSA'];
			if (file_exists($fileName)) {
				$filesize0 = filesize($fileName);
				if ($filesize0 != FALSE) {
					if ($filesize0 > 1024 * 1024 * $maxFileSizeAllowed) {
						die();
					}
				}
			}

			if (1 == 1) {
				// Create lineText to save
				$lineText = $saveString;
				// Encrypt lineText
				$key = pack('H*', $encryptionKeyMails);
				$iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC);
				$iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
				$ciphertext = mcrypt_encrypt(MCRYPT_RIJNDAEL_128, $key, $lineText, MCRYPT_MODE_CBC, $iv);
				$ciphertext = $iv . $ciphertext;
				$ciphertext_base64 = base64_encode($ciphertext);

				/*
				echo "key: ".$key."<br>";
				echo "iv_size: ".$iv_size."<br>";
				echo "iv: ".$iv."<br>";
				echo "ciphertext: ".$ciphertext."<br>";
				echo "ciphertext_base64: ".$ciphertext_base64."<br>";
				*/
				
				// Open a file in write mode
				$fp = fopen($fileName, "a");
				//fwrite($fp, $lineText."\n");	
				fwrite($fp, $ciphertext_base64."\n");
				fclose($fp);
				//echo '<h3>Deze sessie is klaar!</h3><p>Hartelijk dank!<p>U ontvangt later een email met een uitnodiging voor de tweede meting.';
				chmod($fileName, 0600);
			} else {
				echo "Error: The system is unable to plan your next invitation. Please contact thomasgladwin@hotmail.com to correct this and continue the experiment.";
			}
		}
	}
?>
