<?php
	include('header.php');
?>

<!doctype html>

<html>
<head>
	<title>Task</title>
	<script src = "jsfiles/Task/basicHelperFuncs.js"></script>
	<script src = "jsfiles/Task/abstractTask.js"></script>
	<script src = "jsfiles/Task/generalTaskMachine.js"></script>
	<script src = "jsfiles/Task/taskDP_general.js"></script>
	<script src = "jsfiles/Task/taskDP_versions.js"></script>
	<style>
	</style>
</head>

<body onresize="scaleCanvas()" onload="init()">
	<canvas id = "mycanvas" style = "background: black; display:block; margin: 0px auto;" width = "600" height = "600"></canvas>

	<script>
		var generalTaskMachine;
		function init() {
			generalTaskMachine = new generalTaskMachineObj();
			var taskArray;
			taskArray = [taskDP_Baseline, taskDP_Assess];
			<?php
				$_GET['completed'] = 1;
				echo 'generalTaskMachine.init(taskArray, "end.php'.addGET($_GET['sn']).'", subjectCode);';
			?>
		};
		function scaleCanvas() {
			generalTaskMachine.scaleCanvas();
		};
	</script>
</body>

</html>
