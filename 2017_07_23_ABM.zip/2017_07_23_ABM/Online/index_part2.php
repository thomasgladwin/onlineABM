<?php
	include('header.php');
?>

<!doctype html>

<html>
<head>
	<title>Session</title>
	<style>
		body {
			font-family: Arial
		}
		span {
			margin-top: 0%;
			margin-right: 2%;
			background: white;
			max-width: 80%;
			display: inline-block;
		}
	</style>
</head>

<body>
<h1>Reminders</h1>

<p>You are about to start the experiment.</p>

<ol>
<li>Please use <em>Mozilla Firefox</em> as your browser.
<li>Close all other browsers and tabs and avoid all distractions.
<li>Maximize the browser window. 
<li>You can use a desktop or laptop, but not phone or tablet.
<li>If a task seems to stop working, please click on the center of the task-window and press a button used in the task. Check caps-lock.
<li>Tasks may show the current block of trials and the total number of blocks: This always refers to the blocks within the current task, not the total number of blocks in the whole session.
<li>You might perform the same task or complete the same questionnaire more than once.
</ol>

<p>Stay focused on the tasks and respond quickly and accurately.</p>

<?php
	if ($_GET['sn'] == 1 || $_GET['sn'] == $NSessions - 1 || $_GET['sn'] == $NSessions) {
		echo '<form id = "IntroForm" action = "Qs.php'.addGET($_GET['sn']).'" method = "post">';
	} else {
		echo '<form id = "IntroForm" action = "train.php'.addGET($_GET['sn']).'" method = "post">';
	}
?>
	<input type="submit" value="Click here to continue." style="white-space: normal; width: 50%">
</form>

</div>

</body>

</html>
