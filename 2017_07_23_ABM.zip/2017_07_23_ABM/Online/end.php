<?php
	include('header.php');
	testGET();
	include('prep_email_per_session.php');
?>

<!doctype html>

<html>
<head>
	<title>Session complete!</title>
	<style>
	</style>
</head>

<?php
	// Define the message to be sent. Each line should be separated with \n
	$message = $_GET['username']." completed the task\n";
	// Define the receiver of the email
	$to = $researcher_email;
	// Define the subject of the email
	$subject = "Completed session of ".$studyName." session ".$_SESSION["sn"];
	// Define the headers we want passed. Note that they are separated with \r\n
	$headers = "From: tegladwin.com\r\nReply-To: ".$researcher_email;
	//send the email
	$mail_sent = @mail( $to, $subject, $message, $headers );
?>

<body>	
	<h1>Thank you for participating!</h1>

	<?php
		if ($_GET['sn'] == $NSessions && $_GET['loginsrc'] == 'Sona1') {
			echo 'Did you not receive your credits? Please email ".$researcher_email."!';
			echo '<script type="text/javascript">window.location.assign("https://".$SONA1_site."/webstudy_credit.aspx?'.$SONA1.'&survey_code='.$_GET['username'].'");</script>';
		} elseif ($_GET['sn'] == $NSessions && $_GET['loginsrc'] == 'Sona2') {
			echo 'Did you not receive your credits? Please email ".$researcher_email."!';
			echo '<script type="text/javascript">window.location.assign("https://".$SONA2_site."/webstudy_credit.aspx?'.$SONA2.'&survey_code='.$_GET['username'].'");</script>';
		} else {
			echo '<p>You have completed the current session. You can now close the tab or browser.';

		}
	?>
</body>

</html>
