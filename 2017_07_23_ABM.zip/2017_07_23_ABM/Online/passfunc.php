<?php
	// Simple password generator.
	// Note this is only for log-in, not for data encryption.
	
	function generate_password($username) {
		
		// Recode to number_format
		$usernum = 0;
		for ($x = 0; $x < strlen($username); $x++) {
			$this_letter = substr($username, $x, 1);
			if (!ctype_alnum($this_letter)) {
				continue;
			}
			$tmp = ord($this_letter) % 10;
			$tmp = $tmp * 21;
			$usernum = $usernum + $tmp * 10 ^ ($x % 8);
			// echo $this_letter." ".$tmp."<br>";
		}
		
		// Generate password
		$password = cos($usernum + 0.032254788323);
		$password = floor($password * 100000000);
		$rand_fac = 1 * mt_rand() % 10;
		$passlen = strlen("".$password);
		$new_pws = "".$rand_fac.$passlen;
		for ($x = 0; $x < 16; $x++) {
			$tmp = "";
			if ($x < strlen("".$password)) {
				$this_letter = substr($password, $x, 1);
				$tmp = 1 * $this_letter + $rand_fac;
				$tmp = $tmp % 10;
			} else {
				$this_letter = "x";
				$tmp = mt_rand() % 10;
			}
			// echo $rand_fac." ".$passlen." ".$x." ".$this_letter." ".$tmp."<br>";
			$new_pws = $new_pws.$tmp;
		}
		$password_str = $new_pws;
		
		return $password_str;
	}
	
	function test_password($username, $password_input) {
		$password_correct = generate_password($username);

		$rand_fac_input = 1 * substr($password_input, 0, 1);
		$rand_fac_correct = 1 * substr($password_correct, 0, 1);
		$passlen_input = 1 * substr($password_input, 1, 1);
		$passlen_correct = 1 * substr($password_correct, 1, 1);

		if ($passlen_input != $passlen_correct) {
			return 0;
		}
		
		for ($x = 2; $x < $passlen_correct; $x++) {
			$this_letter_input = substr($password_input, $x, 1);
			$num_input = 1 * $this_letter_input - $rand_fac_input;
			$num_input = $num_input % 10;

			$this_letter_correct = substr($password_correct, $x, 1);
			$num_correct = 1 * $this_letter_correct - $rand_fac_correct;
			$num_correct = $num_correct % 10;
			
			if ($num_input < 0) $num_input = $num_input + 10;
			if ($num_correct < 0) $num_correct = $num_correct + 10;
			
			if ($num_input != $num_correct) {
				return 0;
			}
			
			//echo $num_input." ".$num_correct."<br>";
		}
		
		return 1;
	}
?>
