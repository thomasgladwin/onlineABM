<?php
	include('header.php');
	$p = "".$_GET["p"];
	echo "arg0=".$p.PHP_EOL;
	if ($p != $mailPassCode){
		echo 'Bad password';
		die();
	}

	$basedir = $experiment_website.'/'.$studyDir.'/Online';

	date_default_timezone_set('Europe/Amsterdam');

	// Get filenames in mails
	$dir = $basedir.'/mails';
	$timeNow = time();
	echo 'Time now: '.date('Y-m-d H:i', $timeNow).'. <br>';
	if (is_dir($dir)) {
		if ($dh = opendir($dir)) {
			while (($file = readdir($dh)) !== false) {
				try {
					if (pathinfo($file, PATHINFO_EXTENSION) == "txt"){
						$bn = pathinfo($file, PATHINFO_BASENAME);
						$bn_parts = explode("_", $bn);
						if ($bn_parts[0] == "x") {
							continue;
						}
						$timestamp = $bn_parts[1] + 0;
						$sn = $bn_parts[3] + 0;
						if ($timeNow > $timestamp) {
							echo 'Processing '.$bn.', planned for '.date('Y-m-d H:i', $timestamp).'<br>';
							// Read encrypted file
							$handle = @fopen($basedir."/mails/".$bn, "r");
							$input = fgets($handle);
							fclose($handle);
							echo 'Encrypted: '.$input."<br>";
							// Decrypt
							$key = pack('H*', $encryptionKeyMails);
							$iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC);
							$ciphertext_base64 = $input;
							$ciphertext_dec = base64_decode($ciphertext_base64);
							$iv_dec = substr($ciphertext_dec, 0, $iv_size);
							$ciphertext_dec = substr($ciphertext_dec, $iv_size);
							$plaintext_dec = mcrypt_decrypt(MCRYPT_RIJNDAEL_128, $key, $ciphertext_dec, MCRYPT_MODE_CBC, $iv_dec);
							$plaintext_dec = rtrim($plaintext_dec, "\0");
							echo 'Decrypted: '.$plaintext_dec."<br>";
							
							// Deal with underscores in email
							$decr_parts1 = explode("@", $plaintext_dec);
							$email0_1 = $decr_parts1[0];
							
							array_shift($decr_parts1);
							$plaintext_dec2 = implode("_", $decr_parts1);
							
							$decr_parts = explode("_", $plaintext_dec2);
							$_GET['email0'] = $email0_1.'@'.$decr_parts[0];
							$_GET['username'] = $decr_parts[1];
							$_GET['trainingTime'] = $decr_parts[2];
							$_GET['loginsrc'] = $decr_parts[3];
							$_GET['completed'] = 0;
							
							echo 'Email: '.$_GET['email0']."<br>";
							
							echo '<br>var_dump external:<br>';
							var_dump($_GET);
							echo '<br>END var_dump external:<br>';
							
							addGET(300);
							
							echo 'a';
							
							// Send email
							try {
								$message = "Dear participant,\n\nThis is the link for your next session:\n\nhttps://".$experiment_website."/".$studyDir."/Online/index.php".addGET($sn)."\n\n";
								$message = $message."Regards,\n\n".$researcher_name."\n";

								require_once $_SERVER["DOCUMENT_ROOT"].'/Common/swiftmailer-5.x/lib/classes/Swift.php';
								Swift::registerAutoload();
								require_once $_SERVER["DOCUMENT_ROOT"]."/Common/swiftmailer-5.x/lib/swift_init.php";

								//echo '1';
								
								$transport = Swift_SmtpTransport::newInstance('smtp.gmail.com', 587, 'tls');
								$transport->setUsername($researcher_email);
								$transport->setPassword($researcher_email_password);

								//echo '2';

								$mailer = Swift_Mailer::newInstance($transport);

								//echo '3';

								$messageSwift = Swift_Message::newInstance();
								$messageSwift->setSubject('Invitation '.$studyName.' session '.$sn);
								$messageSwift->setFrom(array($researcher_email => $researcher_name));
								$messageSwift->setTo(array(trim($_GET['email0'])));
								$messageSwift->setBody($message, 'text/plain');

								//echo '4';

								$result = $mailer->send($messageSwift);
							} catch (Exception $e) {
								echo 'Email error caught: '.$e.'.<br>';
							}
							$result = 1;
							if ($result == 1) {
								echo '<h3>Uitnodiging gestuurd!</h3>';
								// Tag filename to not be used
								rename($basedir."/mails/".$bn, $basedir."/mails/x_".$bn);
							} else {
								echo '<h3>An error occurred.</h3>';
							}
							
						} else {
							echo 'Skipping '.$bn.', planned for '.date('Y-m-d H:i', $timestamp).'<br>';
						}
						echo '<br>';
					}
				} catch(Exception $e) {
					echo 'Error caught: '.$e.'.<br>';
				}
				
			}
			closedir($dh);
		}
	}

?>
