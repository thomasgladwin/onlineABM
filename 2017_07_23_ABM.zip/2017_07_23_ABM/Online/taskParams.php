<?php
	// Adjust these parameters for your system and experiment.
	
	// Start everything up by having the participant visit the link below, with adjusted username.
	// 		register.php?username=666&loginsrc=Nonsona
	
	// If you are using a SONA system, fill in the web address, id and tokens below and set loginsrc to Sona1 or Sona2 as needed.
	
	// The email systems requires a cronjob with these lines (adjust the studyDir and fake password!):
	// 		#!/bin/sh
	//		curl "https://www.myWebSite.com/2017_07_23_ABM/Online/mailsender.php?p=fakepassword46352"
	
	// The researcher email should be a GMail account set up to accept automated emails.
	
	// If data are encrypted, use unencrypt.php to convert files from subdirectory /resultsToDecrypt to /decrypted_results.
	// No further help: Know what you're doing before encrypting data.
	
	$studyName = 'Online ABM Training';
	$studyDir = '2017_07_23_ABM';
	$experiment_website = '/home/hostingAccountName/myWebSite.com';
	$researcher_name = 'The Researcher';
	$researcher_email = 'myemail@email.com';
	$researcher_email_password = 'myemailpassword';
	$NSessions = 7;
	$final_dstep = 7;
	$mailPassCode = 'fakepassword46352'; // Adjust this in the cron script
	$saveDataPassCode = 'fakepassword46352'; // Adjust this in generalTaskMachine.js
	$encryptionKey = "000000000000000000000000000000000000000000000000000000000000001b";
	$encryptionKeyMails = "000000000000000000000000000000000000000000000000000000000000002a";
	$SONA1_site = "xxx.sona-systems.com";
	$SONA1 = 'experiment_id=xxx&credit_token=xxx';

	$SONA2_site = "xxx.sona-systems.com";
	$SONA2 = 'experiment_id=xxx&credit_token=xxx';
	
	$maxFileSizeAllowed = 200;
	$maxStringLengthAllowed = 100000;

?>
