<?php
	include('header.php');

	$p = "".$_GET["p"];
	echo "arg0=".$p.PHP_EOL;
	if ($p != $mailPassCode){
		echo 'Bad password';
		die();
	}
	
	$basedir = $experiment_website.'/'.$studyDir.'/Online';
	
	date_default_timezone_set('Europe/Amsterdam');

	// Get filenames in mails
	$dir = $basedir.'/mails';
	$timeNow = time();
	echo 'Time now: '.date('Y-m-d H:i', $timeNow).'. <br>';
	if (is_dir($dir)) {
		if ($dh = opendir($dir)) {
			while (($file = readdir($dh)) !== false) {
				try {
					if (pathinfo($file, PATHINFO_EXTENSION) == "txt"){
						$bn = pathinfo($file, PATHINFO_BASENAME);
						$bn_parts = explode("_", $bn);
						if ($bn_parts[0] == "x") {
							//continue;
						}
						$timestamp = $bn_parts[1] + 0;
						$sn = $bn_parts[3] + 0;
						echo 'Processing '.$bn.', planned for '.date('Y-m-d H:i', $timestamp).'<br>';
						// Read encrypted file
						$handle = @fopen($basedir."/mails/".$bn, "r");
						$input = fgets($handle);
						fclose($handle);
						echo 'Encrypted: '.$input."<br>";
						// Decrypt
						$key = pack('H*', $encryptionKeyMails);
						$iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC);
						$ciphertext_base64 = $input;
						$ciphertext_dec = base64_decode($ciphertext_base64);
						$iv_dec = substr($ciphertext_dec, 0, $iv_size);
						$ciphertext_dec = substr($ciphertext_dec, $iv_size);
						$plaintext_dec = mcrypt_decrypt(MCRYPT_RIJNDAEL_128, $key, $ciphertext_dec, MCRYPT_MODE_CBC, $iv_dec);
						$plaintext_dec = rtrim($plaintext_dec, "\0");
						echo 'Decrypted: '.$plaintext_dec."<br>";
/*
				echo "key: ".$key."<br>";
				echo "iv_size: ".$iv_size."<br>";
				echo "iv: ".$iv_dec."<br>";
				echo "ciphertext: ".$ciphertext_dec."<br>";
				echo "ciphertext_base64: ".$ciphertext_base64."<br>";
				*/
						
						// Deal with underscores in email
						$decr_parts1 = explode("@", $plaintext_dec);
						$email0_1 = $decr_parts1[0];
						
						array_shift($decr_parts1);
						//var_dump($decr_parts1);
						$plaintext_dec2 = implode("_", $decr_parts1);
						
						$decr_parts = explode("_", $plaintext_dec2);
						$email0 = $email0_1.'@'.$decr_parts[0];
						$username = $decr_parts[1];
						$trainingTime = $decr_parts[2];
						$loginsrc = $decr_parts[3];
						
						echo 'Email='.$email0.", ID=".$username.", trainingTime=".$trainingTime.", loginsrc=".$loginsrc."<br>";
						echo '<br>';
					}
				} catch(Exception $e) {
					echo 'Error caught: '.$e.'.<br>';
				}
				
			}
			closedir($dh);
		}
	}

?>
