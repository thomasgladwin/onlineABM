var QuestionnaireManagerObj = function() {

	this.questionnairesArray = [];
	this.iQuestionnaire;
	this.activeQuestionnaire;
	this.formNode;
	this.subjString;
	
	// AJAX handling
	this.hr;
	this.AJAX_Timeout;
	this.AJAX_timelimit = 1500;
	
	this.clearChildren = function(node) {
		while (node.hasChildNodes()) {
			node.removeChild(node.lastChild);
		}
	};
	
	this.clearForm = function() {
		this.clearChildren(this.formNode);
	};
	
	this.complete = function() {
		var hiddenField = document.createElement("input"); 
		hiddenField.setAttribute("type", "hidden");
		hiddenField.setAttribute("name", "subjectCode");
		hiddenField.setAttribute("value", this.subjString);
		this.formNode.appendChild(hiddenField);
		this.formNode.submit();
	};
	
	this.setupNextQuestionnaire = function() {
		this.clearForm();
		window.scrollTo(0, 0);
		this.activeQuestionnaire = this.questionnairesArray[this.iQuestionnaire];
		this.activeQuestionnaire.init(this);
	};
	
	this.init = function(formNode, questionnairesArray, subjString) {
		// Get subject number
		this.subjString = subjString;

		// Link to caller
		this.formNode = formNode;
		this.formNode.addEventListener("submit", this.submitHandler.bind(this));
		
		// Store array of questionnaires to run through
		// Note that repeating questionnaire-objects may interfere with clearing screen
		this.questionnairesArray = questionnairesArray;

		// Start
		this.iQuestionnaire = 0;
		this.setupNextQuestionnaire();
	};

	// Send data to PHP page for saving: via AJAX
	this.post_via_ajax = function(url, filename, filenameSubject, trialString, numTries) {
		this.hr = new XMLHttpRequest();
		var vars = "passCode=rabbit&fileNameBase="+filename+"&fileNameSubject="+filenameSubject+"&saveString="+trialString+"&taskIndex="+this.iQuestionnaire;
		this.hr.open("POST", url, true);
		this.hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		this.hr.send(vars);
		// Robustness: If no server response within time limit, retry
		var this_ = this;
		this.AJAX_Timeout = setTimeout(function() {
			console.log('Safety limit');
			this_.hr.abort();
			if (numTries < 3) {
				this_.post_via_ajax(url, filename, filenameSubject, trialString, numTries + 1);
			} else {
				alert("Connection error! Please check your internet connection.");
				this_.continueAfterSaving();
			}
		}, this.AJAX_timelimit);
		this.hr.onreadystatechange = function() {
			if (this_.hr.readyState == 4 && this_.hr.status == 200) {
				clearTimeout(this_.AJAX_Timeout);
				this_.continueAfterSaving();
			};	
		};
	};
	
	this.continueAfterSaving = function() {
		this.endQuestionnaireContinued();
	};
	
	// Setup string to save
	this.saveForm = function() {
		var QData = this.activeQuestionnaire.getJSON();
		var QString = JSON.stringify(QData);
		filename = "Q_" + this.activeQuestionnaire.ID;
		this.post_via_ajax("savepage.php", filename, this.subjString, QString, 0);
	}
	
	this.endQuestionnaireContinued = function() {
		this.iQuestionnaire++;
		if (this.iQuestionnaire >= this.questionnairesArray.length) {
			this.complete();
		} else {
			this.setupNextQuestionnaire();
		}
	};
	
	this.endQuestionnaire = function() {
		this.saveForm();
	};
	
	this.submitHandler = function(event) {
		event.preventDefault();
		var correct = this.activeQuestionnaire.validate();
		if (correct)
			this.endQuestionnaire();
		else {
			alert("Please answer all questions not marked as optional.");
			window.scrollTo(0, 0);
		}
	};
	
	window.addEventListener("keydown", (function(event) {
		if (event.ctrlKey && event.key == "k") {
			this.endQuestionnaire();
		}
	}).bind(this));
};
