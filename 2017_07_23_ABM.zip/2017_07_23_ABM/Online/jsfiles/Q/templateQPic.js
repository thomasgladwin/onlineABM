var adaptToTemplateQPic = function(thisTemplateQ) {
	thisTemplateQ.setupForm = function() {
		var el;
		var Qparent;
		var currSpan;
		var optDiv;
		var input;
		var txt;
		
		// Title
		el = document.createElement("p");
		el.class = "cQuestion";
		el.innerHTML = this.title;
		this.caller.formNode.appendChild(el);
		
		// Instructions
		el = document.createElement("p");
		el.class = "cQuestion";
		el.innerHTML = this.instructions;
		this.caller.formNode.appendChild(el);
		
		// Questions
		for (var iQ = 0; iQ < this.types.length; iQ++) {
			// Question <p>, class used as tag in code for validation
			Qparent = document.createElement("p");
			Qparent.className = "cQuestion";
			Qparent.style.padding = "1%";
			
			// Question text -> Image
			if (this.texts[iQ].length > 0) {
				currSpan = document.createElement("img");
				currSpan.src = this.texts[iQ];
				//currSpan.style.display = "block";
				//currSpan.style.border = "1px #000000 solid";
				//currSpan.style.margin = "1%";
				Qparent.appendChild(currSpan);

				Qparent.appendChild(document.createElement("br"));
			}
			
			// Options span
			optDiv = document.createElement("div");
			optDiv.style.padding = "2px";
			optDiv.style.border = "none"; "1px #000000 solid";
			optDiv.style.display = "inline";
			
			// Question options
			if (this.types[iQ] == "radio") {
				for (var iO = 0; iO < this.options[iQ].length; iO++) {
					var thisOption = this.options[iQ][iO];
					currSpan = document.createElement("span");
					currSpan.setAttribute("style", "background-color: #DDDDDD;");
					currSpan.innerHTML = thisOption;
					input = document.createElement("input");
					input.type = "radio";
					input.value = thisOption;
					input.name = this.qName(iQ);
					currSpan.appendChild(input);
					optDiv.appendChild(currSpan);
				}
			} else if (this.types[iQ] == "text") {
				var thisOption = this.options[iQ];
				currSpan = document.createElement("span");
				currSpan.innerHTML = thisOption;
				input = document.createElement("input");
				input.type = "text";
				input.value = thisOption;
				input.name = this.qName(iQ);
				currSpan.appendChild(input);
				optDiv.appendChild(currSpan);
			}
			optDiv.addEventListener("click", this.revalidate.bind(this));
			Qparent.appendChild(optDiv);

			// Add divider
			var divvy = document.createElement("div");
			divvy.setAttribute("style", "width: 100%; height: 1px; background-color: #AAAAAA; margin: 1%;");
			Qparent.appendChild(divvy);
			
			// Add to form
			this.caller.formNode.appendChild(Qparent);
		};

		// Submit button
		var submitButton = document.createElement("button");
		submitButton.type = "submit";
		submitButton.style.display = "block";
		submitButton.style.margin = "0 auto";
		submitButton.innerHTML = this.completeButtonText;
		this.caller.formNode.appendChild(submitButton);
		
		var footer = document.createElement("div");
		footer.style.border = "1px solid black";
		footer.style.margin = "2%";
		this.caller.formNode.appendChild(footer);

	};
};
