var TemplateQ = function() {

	this.ID;
	this.title;
	this.instructions;
	this.types = [];
	this.texts = [];
	this.options = [];
	this.check = [];
	this.validated;
	// Link to caller for submit eventListener
	this.caller;
	
	this.defineQuestionnaire = function() {
		this.ID = "template";
		this.title = "Test";
		this.instructions = "Instructions<br>Second line.";
		// Q1
		this.types.push("radio");
		this.texts.push("Q1");
		this.options.push(["Yes", "No"]);
		this.check.push(true);
		// Q2
		this.types.push("radio");
		this.texts.push("Q2");
		this.options.push(["Yes", "No"]);
		this.check.push(true);
		// Q3
		this.types.push("radio");
		this.texts.push("Q3 (opt)");
		this.options.push(["Yes", "No"]);
		this.check.push(false);
		// Q4
		this.types.push("text");
		this.texts.push("Q4");
		this.options.push("");
		this.check.push(true);
		// Q5
		this.types.push("text");
		this.texts.push("Q5 (opt)");
		this.options.push("");
		this.check.push(false);	
		
		this.completeButtonText = "Click here to complete this questionnaire.";
	};
	
	this.qName = function(iQ) {
		return this.ID + "_Q_ " + iQ;
	};
	
	this.setupForm = function() {
		var el;
		var Qparent;
		var currSpan;
		var optDiv;
		var input;
		var txt;
		
		// Title
		el = document.createElement("p");
		el.class = "cQuestion";
		el.innerHTML = this.title;
		this.caller.formNode.appendChild(el);
		
		// Instructions
		el = document.createElement("p");
		el.class = "cQuestion";
		el.innerHTML = this.instructions;
		this.caller.formNode.appendChild(el);
		
		// Questions
		for (var iQ = 0; iQ < this.types.length; iQ++) {
			// Question <p>, class used as tag in code for validation
			Qparent = document.createElement("p");
			Qparent.className = "cQuestion";
			Qparent.style.padding = "1%";
			
			// Question text
			currSpan = document.createElement("span");
			currSpan.innerHTML = this.texts[iQ];
			currSpan.style.display = "block";
			//currSpan.style.border = "1px #000000 solid";
			// currSpan.style.margin = "1%";
			Qparent.appendChild(currSpan);

			Qparent.appendChild(document.createElement("br"));
			
			// Options span
			optDiv = document.createElement("div");
			optDiv.style.padding = "2px";
			optDiv.style.border = "none"; // "1px #000000 solid";
			optDiv.style.display = "inline";
			
			// Question options
			if (this.types[iQ] == "radio") {
				for (var iO = 0; iO < this.options[iQ].length; iO++) {
					var thisOption = this.options[iQ][iO];
					currSpan = document.createElement("span");
					currSpan.setAttribute("style", "background-color: #DDDDDD;");
					currSpan.innerHTML = thisOption;
					input = document.createElement("input");
					input.type = "radio";
					input.value = thisOption;
					input.name = this.qName(iQ);
					currSpan.appendChild(input);
					optDiv.appendChild(currSpan);
				}
			} else if (this.types[iQ] == "text") {
				var thisOption = this.options[iQ];
				currSpan = document.createElement("span");
				currSpan.innerHTML = thisOption;
				input = document.createElement("input");
				input.type = "text";
				input.value = thisOption;
				input.name = this.qName(iQ);
				currSpan.appendChild(input);
				optDiv.appendChild(currSpan);
			}
			optDiv.addEventListener("click", this.revalidate.bind(this));
			Qparent.appendChild(optDiv);
			
			// Add divider
			var divvy = document.createElement("div");
			divvy.setAttribute("style", "width: 100%; height: 1px; background-color: #AAAAAA; margin: 1%;");
			Qparent.appendChild(divvy);

			// Add to form
			this.caller.formNode.appendChild(Qparent);
			
		};

		// Submit button
		var submitButton = document.createElement("button");
		submitButton.type = "submit";
		submitButton.style.display = "block";
		submitButton.style.margin = "0 auto";
		submitButton.innerHTML = this.completeButtonText;
		this.caller.formNode.appendChild(submitButton);
		
		var footer = document.createElement("div");
		footer.style.border = "1px solid black";
		footer.style.margin = "2%";
		this.caller.formNode.appendChild(footer);

	};
	
	this.init = function(caller) {
		this.caller = caller;
		this.validated = false;
		this.defineQuestionnaire();
		this.setupForm();
	};

	this.runDownForChecked = function(node) {
		if (node.checked === true)
			return true;
		var subnodes = node.childNodes;
		if (subnodes.length == 0)
			return false;
		var subchecked = false;
		for (var j = 0; j < subnodes.length; j++) {
			subchecked = subchecked || this.runDownForChecked(subnodes[j]);
		}
		return subchecked;
	};
	
	this.runDownForText = function(node) {
		if (node.type === "text") {
			return node.value.length > 0;
		} else {
			var children = node.childNodes;
			var subchecked = false;
			for (var i = 0; i < children.length; i++) {
				subchecked = subchecked || this.runDownForText(children[i]);
			}
			return subchecked;
		}
	};
	
	this.validate = function() {
		var questions = document.getElementsByClassName("cQuestion");
		var allchecked = true;
		for (var i = 0; i < questions.length; i++) {
			if (this.check[i] == false)
				continue;
			var thischecked = false;
			if (this.types[i] == "radio")
				thischecked = this.runDownForChecked(questions[i]);
			else if (this.types[i] == "text") {
				thischecked = this.runDownForText(questions[i]);
			}
			allchecked = allchecked && thischecked;
			if (thischecked == false) {
				questions[i].childNodes[0].style = "background: rgb(250, 150, 150);";
			} else {
				questions[i].childNodes[0].style = "background: white;";
			}
		}
		this.validated = true;
		return allchecked;
	};
	
	this.revalidate = function() {
		if (this.validated == true)
			this.validate();
	};
	
	this.getJSON = function() {
		var QData = [];
		for (var iQ = 0; iQ < this.texts.length; iQ++) {
			var qName = this.qName(iQ);
			if (this.types[iQ] == "radio") {
				var node = document.querySelector('input[name = "' + qName + '"]:checked');
				var ans = null;
				if (node != null)
					ans = node.value;
			} else if (this.types[iQ] == "text") {
				var ans = document.querySelector('input[name = "' + qName + '"]').value;
			}
			//console.log(qName + " " + ans);
			QData.push([qName, ans]);
		}
		return QData;
	};
};
