
var evalQ_Intro = new TemplateQ(); // Introduce a rage and a neutral face for reference
adaptToTemplateQPic(evalQ_Intro);
evalQ_Intro.defineQuestionnaire = function() {
	this.ID = "evalQ_Intro";
	this.title = "<b>Stimulus evaluatie</b>";
	this.instructions = "<p>Bekijk even deze gezichten.</p>";
	this.instructions += "<p><img src='Stim/FacesNeutral/stim (45).jpg' height=20%>";
	this.instructions += "<img src='Stim/FacesAngry/stim (45).jpg' height=20%></p>";

	for (var i = 0; i < this.texts.length; i++) {
		this.types.push("radio");
		this.check.push(true);
	}
		
	this.completeButtonText = "Klik hier om door te gaan.";
};

var evalQ_Neutral = new TemplateQ(); // Introduce a rage and a neutral face for reference
adaptToTemplateQPic(evalQ_Neutral);
evalQ_Neutral.defineQuestionnaire = function() {
	this.ID = "evalQ_Neutral";
	this.title = "<b>Stimulus evaluatie</b>";
	this.instructions = "<p>Hoe voel jij je wanneer je naar dit gezicht kijkt? Geef de mate aan waarin het gezicht deze gevoelens in jou opwekt.</p>";
	this.instructions += "<p><img src='Stim/FacesNeutral/stim (45).jpg' height=20%></p>";

	this.options.push(["Onprettig?<br>Helemaal niet (1)", "2", "3", "een beetje (4)", "5", "6", "helemaal wel (7)"]);
	this.options.push(["Opgewonden?<br>Helemaal niet (1)", "2", "3", "een beetje (4)", "5", "6", "helemaal wel (7)"]);
	this.options.push(["Bang?<br>Helemaal niet (1)", "2", "3", "een beetje (4)", "5", "6", "helemaal wel (7)"]);
	this.options.push(["Agressief?<br>Helemaal niet (1)", "2", "3", "een beetje (4)", "5", "6", "helemaal wel (7)"]);
	this.options.push(["Alsof ik mezelf minder onder controle heb?<br>Helemaal niet (1)", "2", "3", "een beetje (4)", "5", "6", "helemaal wel (7)"]);
	this.options.push(["Beschaamd?<br>Helemaal niet (1)", "2", "3", "een beetje (4)", "5", "6", "helemaal wel (7)"]);
	this.options.push(["Respectloos behandeld?<br>Helemaal niet (1)", "2", "3", "een beetje (4)", "5", "6", "helemaal wel (7)"]);

	for (var i = 0; i < this.options.length; i++) {
		this.texts.push("");
		this.types.push("radio");
		this.check.push(true);
	}
	
	this.completeButtonText = "Klik hier om door te gaan.";
};

var evalQ_Rage = new TemplateQ();
adaptToTemplateQPic(evalQ_Rage);
evalQ_Rage.defineQuestionnaire = function() {
	this.ID = "evalQ_Rage";
	this.title = "<b>Stimulus evaluatie</b>";
	this.instructions = "<p>Hoe voel jij je wanneer je naar dit gezicht kijkt? Geef de mate aan waarin het gezicht deze gevoelens in jou opwekt.</p>";
	this.instructions += "<p><img src='Stim/FacesAngry/stim (45).jpg' height=20%></p>";

	this.options.push(["Onprettig?<br>Helemaal niet (1)", "2", "3", "een beetje (4)", "5", "6", "helemaal wel (7)"]);
	this.options.push(["Opgewonden?<br>Helemaal niet (1)", "2", "3", "een beetje (4)", "5", "6", "helemaal wel (7)"]);
	this.options.push(["Bang?<br>Helemaal niet (1)", "2", "3", "een beetje (4)", "5", "6", "helemaal wel (7)"]);
	this.options.push(["Agressief?<br>Helemaal niet (1)", "2", "3", "een beetje (4)", "5", "6", "helemaal wel (7)"]);
	this.options.push(["Alsof ik mezelf minder in controle heb?<br>Helemaal niet (1)", "2", "3", "een beetje (4)", "5", "6", "helemaal wel (7)"]);
	this.options.push(["Beschaamd?<br>Helemaal niet (1)", "2", "3", "een beetje (4)", "5", "6", "helemaal wel (7)"]);
	this.options.push(["Respectloos behandeld?<br>Helemaal niet (1)", "2", "3", "een beetje (4)", "5", "6", "helemaal wel (7)"]);

	for (var i = 0; i < this.options.length; i++) {
		this.texts.push("");
		this.types.push("radio");
		this.check.push(true);
	}
	
	this.completeButtonText = "Klik hier om door te gaan.";
};