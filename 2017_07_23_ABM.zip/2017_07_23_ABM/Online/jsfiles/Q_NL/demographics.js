var demoQ = new TemplateQ();

demoQ.defineQuestionnaire = function() {
	this.ID = "demoQ";
	this.title = "<b>Demographic information</b>";
	this.instructions = "<p>Beantwoord iedere van de volgende vragen. Kies het antwoord dat het beste bij jou past.</p>";
	
	this.texts.push("Geslacht.");
	this.options.push(["Man", "Vrouw", "Overig / geen antwoord"]);
	this.types.push("radio");
	this.check.push(true);

	this.texts.push("Leeftijd.");
	this.options.push("");
	this.types.push("text");
	this.check.push(true);

	this.texts.push("Welke type computer gebruikt u?");
	this.options.push(["Desktop", "Laptop"]);
	this.types.push("radio");
	this.check.push(true);
	
	/*
	this.texts.push("Highest education level.");
	this.options.push("");
	this.types.push("text");
	this.check.push(true);

	this.texts.push("Nationality.");
	this.options.push("");
	this.types.push("text");
	this.check.push(true);
	*/
	
	this.completeButtonText = "Druk hier nadat je alle vragen hebt beantwoord.";
};
