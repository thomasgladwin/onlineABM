var adhocQ = new TemplateQ();

adhocQ.defineQuestionnaire = function() {
	this.ID = "tegQ";
	this.title = "<b>adhocQ</b>";
	this.instructions = "<p>Please respond to the following statements; these refer to your experiences over the <strong>last one week</strong>. Answer on the scale from 0 to 6. Choose the answer that fits best.</p>";
	
	this.texts.push("I had difficulty suppressing impulsive responses.");
	this.texts.push("I felt stressed.");
	this.texts.push("I quickly became angry.");
	this.texts.push("I was verbally abusive to other people.");
	this.texts.push("I felt a strong tendency towards physical violence.");
	this.texts.push("My emotions were overwhelming.");
	this.texts.push("I was very anxious about social interactions.");
	this.texts.push("I was worried about getting criticism.");
	this.texts.push("I was worried about being rejected.");
	this.texts.push("I was worried that people would be hostile towards me.");

	// Response options
	for (var i = 0; i < this.texts.length; i++) {
		this.options.push(["Strongly disagree (0)", "(1)", "Disagree (2)", "(3)", "Agree (4)", "(5)", "Strongly agree (6)"]);
	}
	
	// Parameters
	for (var i = 0; i < this.texts.length; i++) {
		this.types.push("radio");
		this.check.push(true);
	}

	this.completeButtonText = "Click here after answering all the questions.";
};
