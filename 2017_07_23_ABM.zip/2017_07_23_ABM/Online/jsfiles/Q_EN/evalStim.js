// FACE questionnaire, first reference: 

var evalQ_Intro = new TemplateQ(); // Introduce a rage and a neutral face for reference
adaptToTemplateQPic(evalQ_Intro);
evalQ_Intro.defineQuestionnaire = function() {
	this.ID = "evalQ_Intro";
	this.title = "<b>Stimulus evaluation</b>";
	this.instructions = "<p>Take a brief look at the following faces.</p>";
	this.instructions += "<p><img src='Stim/FacesNeutral/stim (45).jpg' height=20%>";
	this.instructions += "<img src='Stim/FacesAngry/stim (45).jpg' height=20%></p>";

	for (var i = 0; i < this.texts.length; i++) {
		this.types.push("radio");
		this.check.push(true);
	}
		
	this.completeButtonText = "Click here to continue.";
};

var evalQ_Neutral = new TemplateQ(); // Introduce a rage and a neutral face for reference
adaptToTemplateQPic(evalQ_Neutral);
evalQ_Neutral.defineQuestionnaire = function() {
	this.ID = "evalQ_Neutral";
	this.title = "<b>Stimulus evaluation</b>";
	this.instructions = "<p>How does this face make you feel when you look at it? Indicate the degree to which the face evokes the feelings in you.</p>";
	this.instructions += "<p><img src='Stim/FacesNeutral/stim (45).jpg' height=20%></p>";

	this.options.push(["Unpleasant?<br>Not at all (1)", "2", "3", "Somewhat (4)", "5", "6", "Extremely (7)"]);
	this.options.push(["Tense or suspenseful?<br>Not at all (1)", "2", "3", "Somewhat (4)", "5", "6", "Extremely (7)"]);
	this.options.push(["Scared?<br>Not at all (1)", "2", "3", "Somewhat (4)", "5", "6", "Extremely (7)"]);
	this.options.push(["Aggressive?<br>Not at all (1)", "2", "3", "Somewhat (4)", "5", "6", "Extremely (7)"]);
	this.options.push(["Out of control?<br>Not at all (1)", "2", "3", "Somewhat (4)", "5", "6", "Extremely (7)"]);
	this.options.push(["Ashamed?<br>Not at all (1)", "2", "3", "Somewhat (4)", "5", "6", "Extremely (7)"]);
	this.options.push(["Sad?<br>Not at all (1)", "2", "3", "Somewhat (4)", "5", "6", "Extremely (7)"]);

	for (var i = 0; i < this.options.length; i++) {
		this.texts.push("");
		this.types.push("radio");
		this.check.push(true);
	}
	
	this.completeButtonText = "Click here to continue.";
};

var evalQ_Rage = new TemplateQ();
adaptToTemplateQPic(evalQ_Rage);
evalQ_Rage.defineQuestionnaire = function() {
	this.ID = "evalQ_Rage";
	this.title = "<b>Stimulus evaluation</b>";
	this.instructions = "<p>How does this face make you feel when you look at it? Indicate the degree to which the face evokes the feelings in you.</p>";
	this.instructions += "<p><img src='Stim/FacesAngry/stim (45).jpg' height=20%></p>";

	this.options.push(["Unpleasant?<br>Not at all (1)", "2", "3", "Somewhat (4)", "5", "6", "Extremely (7)"]);
	this.options.push(["Tense or suspenseful?<br>Not at all (1)", "2", "3", "Somewhat (4)", "5", "6", "Extremely (7)"]);
	this.options.push(["Scared?<br>Not at all (1)", "2", "3", "Somewhat (4)", "5", "6", "Extremely (7)"]);
	this.options.push(["Aggressive?<br>Not at all", "2", "3", "Somewhat (4)", "5", "6", "Extremely (7)"]);
	this.options.push(["Out of control?<br>Not at all (1)", "2", "3", "Somewhat (4)", "5", "6", "Extremely (7)"]);
	this.options.push(["Ashamed?<br>Not at all (1)", "2", "3", "Somewhat (4)", "5", "6", "Extremely (7)"]);
	this.options.push(["Sad?<br>Not at all (1)", "2", "3", "Somewhat (4)", "5", "6", "Extremely (7)"]);

	for (var i = 0; i < this.options.length; i++) {
		this.texts.push("");
		this.types.push("radio");
		this.check.push(true);
	}
	
	this.completeButtonText = "Click here to continue.";
};
