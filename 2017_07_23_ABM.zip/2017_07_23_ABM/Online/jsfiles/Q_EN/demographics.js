var demoQ = new TemplateQ();

demoQ.defineQuestionnaire = function() {
	this.ID = "demoQ";
	this.title = "<b>Demographic information</b>";
	this.instructions = "<p>Please answer the following questions. Choose the answer that fits best.</p>";
	
	this.texts.push("Sex.");
	this.options.push(["Male", "Female", "Other / no answer"]);
	this.types.push("radio");
	this.check.push(true);

	this.texts.push("Age.");
	this.options.push("");
	this.types.push("text");
	this.check.push(true);

	this.texts.push("What kind of computer are you using?");
	this.options.push(["Desktop", "Laptop"]);
	this.types.push("radio");
	this.check.push(true);

	/*
	this.texts.push("Highest education level.");
	this.options.push("");
	this.types.push("text");
	this.check.push(true);

	this.texts.push("Nationality.");
	this.options.push("");
	this.types.push("text");
	this.check.push(true);
	*/
	
	this.completeButtonText = "Click here after answering all the questions.";
};
