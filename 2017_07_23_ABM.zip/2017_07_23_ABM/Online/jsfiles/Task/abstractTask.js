"use strict";

// Template for a basic blocks -> trials -> {ITI, Cue, Stim, Feedback} task.
// To specify: add task-specific variables and adjust the interface functions and arrays:
// - taskSpecificInit
// - stimArrParamsMaker
// - respEvents
// - TaskInstr and BlockIntro if necessary
// - counterbalancing
// - logTrialData

var templateTaskObj = function() {
	//
	// Variable declarations
	//

	this.taskName = "abstractTask";
	
	// Connections with higher-level code
	this.caller;
	this.subjName;
	this.subjNr;

	// Parameters
	this.nBlocks;
	this.nTrials;

	// Stimuli
	this.nStimCat;
	this.nStim = [];
	this.stimType;
	this.stimArrParams = []; // filenames for img, text for string
	this.stimArr = []; // mixture of img and string
	this.stimuliLoaded = 0;

	// Trial variables
	this.iBlock;
	this.iTrial;
	this.iTrialStep = 0;
	this.stimTime;
	this.trialEventFun = [];
	this.trialDurs = [];
	this.trialStims = [];
	this.trialData;
	
	// Randomization
	this.stimIndex;
	this.stimIndexer = [];
	
	// Responses
	this.respKeys = []; // Note capitalization
	this.respCodes = []; // Specified at init() to allow respKeys to be set first
	this.respTime;
	this.RT;
	this.acc;
	this.respID;
	this.responses = [];
	this.keyUp = 1;
	
	// Duration-related
	this.durations0 = []; // ITI, CSI, respWindow
	this.waitToStartTask = 0;
	this.waitToStartBlock = 0;
	this.waitForResponse = 0;
	this.currentTimeout;

	//
	// Task-level helper functions
	//

	this.logTrialData = function() {
		this.trialData = {
			iBlock: this.iBlock,
			blockStartTime: this.blockStartTime,
			stimTime: this.stimTime,
			iTrial: this.iTrial,
			cue: this.cue,
			respTimeEvent: this.respTimeEvent,
			respTime: this.respTime,
			RT: this.RT, 
			acc: this.acc, 
			respID: this.respID, 
			trialStims: this.trialStims,
			responses: this.responses,
			trialDurs: this.trialDurs
		};
		this.caller.saveData(this.trialData, this.taskName, this.subjName);
	}

	this.setupStimIndexer = function() {
		this.stimIndex = [];
		for (var j = 0; j < this.nStimCat; j++)
			this.stimIndex.push(0);
		for (var j = 0; j < this.nStimCat; j++) {
			var subarr = [];
			for (var i = 0; i < this.nStim[j]; i++) {
				subarr.push(i);
			}
			this.stimIndexer.push(subarr);
		}
	};

	this.shuffleStim = function(j) {
		this.stimIndexer[j].shuffle(0, this.stimIndexer[j].length - 2);
		this.stimIndexer[j].shuffle(1, this.stimIndexer[j].length - 1);
	};

	this.updateStimIndex = function(stimCat) {
		this.stimIndex[stimCat]++;
		if (this.stimIndex[stimCat] >= this.stimIndexer[stimCat].length) {
			this.stimIndex[stimCat] = 0;
			this.shuffleStim(stimCat);
		}
	};
	
	//
	// Trial event chain functions
	//
	
	this.trialEventFun[0] = function() {
		this.caller.emptyCanvas();
		this.caller.showText("+", 0, 0, "white");
	};
	
	this.trialEventFun[1] = function() {
		this.caller.emptyCanvas();
		this.caller.showText("Cue", 0, 0, "white");
	};

	this.trialEventFun[2] = function() {
		this.caller.emptyCanvas();
		this.caller.showText("Stim", 0, 0, "white");
	};

	this.trialEventFun[3] = function() {
		this.caller.emptyCanvas();
		this.caller.showText("Feedback", 0, 0, "white");
	};
	
	//
	// Run trials
	//
	this.executeTrialStep = function() {
		// Make sure iTrialStep is incremented before any other function is called:
		// otherwise function could call executeTrialStep and get into infinite loop.
		// Also: set timeout before calling current function, as currentTimeout may need
		// to be cleared in the current event.
		this.iTrialStep++; 
		if (this.iTrialStep > this.trialEventFun.length) {
			this.endTrial();
			return;
		}
		var dur0v = this.durations0[this.iTrialStep - 1];
		var dur0 = dur0v[Math.floor(Math.random() * dur0v.length)];
		this.trialDurs.push(dur0);
		if (dur0 > 0) {
			this.currentTimeout = setTimeout(this.executeTrialStep.bind(this), dur0);
		} else if (dur0 == -1) {
			this.waitForResponse = 1;
		}
		this.trialEventFun[this.iTrialStep - 1].call(this);
	};
	
	this.endTrial = function() {
		this.logTrialData();
		this.iTrial++;
		// Start of next trial controlled by savedata / post_via_ajax in generalTaskMachine
	};

	this.nextTrial = function() {
		this.trialTime = Date.now();
		this.respTime = 0;
		this.RT = -1;
		this.acc = -1;
		this.respID = -1;
		this.iTrialStep = 0;
		this.responses.clear();
		this.trialStims.clear();
		this.trialDurs.clear();
		this.trialData = "";
		this.waitForResponse = 0;
		this.executeTrialStep();
	};
	
	//
	// Run blocks
	//

	this.endBlock = function() {
		this.iBlock++;
		if (this.iBlock < this.nBlocks)
			this.nextBlock();
		else
			this.endTask();
	};

	this.blockIntro = function() {
		this.caller.borderCanvas();
		this.caller.showText("Block " + (this.iBlock + 1) + " of " + this.nBlocks, 0, -0.25, "white");
		this.caller.showText("Press one of the keys to continue.", 0, 0.25, "white");
		this.blockStartTime = Date.now();
		this.waitToStartBlock = 1;
	};

	this.nextBlock = function() {
		this.iTrial = 0;
		this.blockIntro();
	};

	//
	// Run task
	//

	this.endTask = function() {
		this.caller.endTask();
	};

	this.taskInstr = function() {
		this.caller.emptyCanvas();
		var str0 = "Als u een negatief plaatje ziet,";
		this.caller.showText(str0, 0, -0.25, "white");
		var str0 = "druk dan zo snel mogelijk op spatie.";
		this.caller.showText(str0, 0, 0, "white");
		this.caller.showText("Druk op een toets om te beginnen.", 0, 0.5, "white");
		this.waitToStartTask = 1;
	};
	
	this.startTask = function() {
		this.caller.scaleCanvas();
		for (var i = 0; i < this.stimArr.length; i++)
			this.shuffleStim(i);
		this.iBlock = 0;
		this.taskInstr();
	};

	//
	// Initialization: Load images and start task when ready
	//

	this.stimArrParamsMaker = function() {
		for (var j = 0; j < this.nStimCat; j++) {
			var subarr = [];
			if (this.stimType[j] == "img") {
				for (var i = 0; i < this.nStim[j]; i++) {
					subarr.push((function(i) {
						var fn0;
						if (j == 0) fn0 = "Stim/animalNeg (" + (i + 1) + ").jpg";
						else fn0 = "Stim/animalPos (" + (i + 1) + ").jpg";
						return fn0;
					})(i));
				}
			} else if (this.stimType[j] == "string") {
				for (var i = 0; i < this.nStim[j]; i++) {
					subarr.push((function(i) {
						var word0;
						word0 = "W" + j + "_" + i;
						return word0;
					})(i));
				}
			}
			this.stimArrParams.push(subarr);
		}
	}

	this.loaded_a_stim = function() {
		this.nStimLoaded++;
		var nStimTotal = 0;
		for (var n = 0; n < this.nStimCat; n++) {
			for (var m = 0; m < this.nStim[n]; m++) {
				nStimTotal++;
			}
		}
		console.log(this.nStimLoaded + " " + nStimTotal);
		if (this.nStimLoaded >= nStimTotal) {
			this.startTask();
		}
	};
	
	this.createNextStim = function(j, i, subarr) {
		if (i < this.nStim[j] && j < this.nStimCat) {
			if (this.stimType[j] == "img") {
				var img = document.createElement("img");
				img.src = this.stimArrParams[j][i];
				img.width = 200;
				img.height = 200;
				subarr.push(img);
				i++;
				img.addEventListener("load", this.loaded_a_stim.bind(this, j, i, subarr));
				this.createNextStim(j, i, subarr);
			} else if (this.stimType[j] == "string") {
				subarr.push(this.stimArrParams[j][i]);
				i++;
				this.loaded_a_stim();
				this.createNextStim(j, i, subarr);
			}
		} else {
			this.stimArr.push(subarr);
			j++;
			if (j >= this.nStimCat) {
				// this.startTask();
			} else {
				subarr = [];
				i = 0;
				this.createNextStim(j, i, subarr);
			}
		}
	};
	
	this.createStimArr = function() {
		this.stimArrParamsMaker();
		this.stimArr.clear();
		this.nStimLoaded = 0;
		this.createNextStim(0, 0, []);
	}
	
	this.taskSpecificInit = function() {
		// Counterbalancing: make sure this is done at an appropriate location, i.e., after necessary declarations
		this.counterbalancing();
		// taskName, used for save filename
		this.taskName = "Template";
		// Basic parameters
		this.nBlocks = 1;
		this.nTrials = 2;
		// Response keys
		this.respKeys.clear();
		this.respKeys = [" "]; // Note capitalization
		// Durations
		if (typeof this.durations0 !== 'undefined') {
			this.durations0.clear();
		}
		this.durations0 = [[350, 500, 650], [300, 600, 800], [-1], [250]]; // ITI, CSI, respWindow
		// Stim
		this.nStimCat = 2;
		this.nStim = [16, 16];
		this.stimType = []; // "img", "string"
		for (var j = 0; j < this.nStimCat; j++)
			this.stimType.push("img");
	};
	
	this.counterbalancing = function() {
	};
	
	this.init = function(caller, subjStr) {
		// Collect connection variables
		this.caller = caller;
		this.subjName = subjStr;
		this.subjNr = teg_str2ascsum(subjStr);
		// Task-specific init
		this.taskSpecificInit();
		// Response codes: respKeys must be set first!
		for (var i = 0; i < this.respKeys.length; i++) {
			this.respCodes.push(this.respKeys[i].charCodeAt(0));
		}
		// Randomization init
		this.setupStimIndexer();
		// Stimulus init (must follow setupStimIndexer); task is started when images are all loaded
		this.caller.showText("Preparing task, please wait", 0, -0.5, "gray");
		this.createStimArr();
	};

	//
	// Response handling
	//

	this.logResp = function() {
		var respObj = {respTimeEvent: this.respTimeEvent, respTime: this.respTime, respID: this.respID, respRT: this.RT};
		this.responses.push(respObj);
	};

	// Response-triggered events
	this.respEvents = function() {
		if (this.RT > 0)
			acc = 1;
		if (this.waitToStartTask == 1) {
			this.waitToStartTask = 0;
			this.nextBlock();
			return;
		}
		if (this.waitToStartBlock == 1) {
			this.waitToStartBlock = 0;
			this.nextTrial();
			return;
		}
		if (this.waitForResponse == 1) {
			this.waitForResponse = 0;
			clearTimeout(this.currentTimeout);
			this.executeTrialStep();
			return;
		}
	};

	this.respHandler = function(event) {
		// Parse responses
		if (this.keyUp == 0) return;

		this.respTime = Date.now();
		if ('timeStamp' in event) {
			this.respTimeEvent = event.timeStamp;
		} else {
			this.respTimeEvent = 0;
		}
		this.RT = this.respTime - this.stimTime;
		this.respID = -1;
		this.acc = -1;
		for (var i = 0; i < this.respCodes.length; i++) {
			if (event.keyCode == this.respCodes[i])
				this.respID = i;
		}

		if (this.respID == -1) return;
		
		this.logResp();

		this.respEvents();
		
		this.keyUp = 0;
	};

	this.respHandlerUp = function(event) {
		this.keyUp = 1;
	};
	
};
