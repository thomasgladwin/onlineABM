"use strict";

var taskDP_Baseline = new templateTaskObj();
adaptTemplateToDP(taskDP_Baseline, 0);

var taskDP_Assess = new templateTaskObj();
adaptTemplateToDP(taskDP_Assess, 1);

var taskDP_Train = new templateTaskObj();
adaptTemplateToDP(taskDP_Train, 2);
