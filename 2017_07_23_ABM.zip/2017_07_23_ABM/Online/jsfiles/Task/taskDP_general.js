"use strict";

var adaptTemplateToDP = function(thisTask, taskVariant) {

	//
	// Adjust template to specific task
	//

	thisTask.taskVariant = taskVariant; // Assumed to be 0, 1 or 2
	if (thisTask.taskVariant == 0) {
		thisTask.taskName = "DP_Baseline";
	} else if (thisTask.taskVariant == 1) {
		thisTask.taskName = "DP_Assess";
	} else if (thisTask.taskVariant == 2) {
		thisTask.taskName = "DP_Train";
	}

	thisTask.taskSpecificInit = function() {
		this.nTrainingConditions = 4;
		this.trainingCondition = 0; 
			// 0 = Assess
			// 1 = Train: Null
			// 2 = Train: Random
			// 3 = Train: Attend-Away
			// 4 = Train: Attend-Towards

		if (this.taskVariant == 0) { // baseline
			this.stimSubdir0 = "Neutral";
			this.stimSubdir1 = "Emotional";
			this.stimExt = "jpg";
			this.nBlocks = 1;
			this.nTrialsPerBlock = 12;
			this.showPictures = 0;
		} else if (this.taskVariant == 1) { // DP Assess
			this.stimSubdir0 = "Neutral";
			this.stimSubdir1 = "Emotional";
			this.stimExt = "jpg";
			this.nBlocks = 8;
			this.nTrialsPerBlock = 48;
			this.showPictures = 1;
		} else if (this.taskVariant == 2) { // DP Train
			this.stimSubdir0 = "NeutralTrain";
			this.stimSubdir1 = "EmotionalTrain";
			this.stimExt = "jpg";
			this.nBlocks = 8;
			this.nTrialsPerBlock = 48;
			var j = Math.floor(Math.random() * this.nTrainingConditions);
			this.trainingCondition = 1 + j;
			if (this.trainingCondition == 1) {
				this.showPictures = 0;
			} else {
				this.showPictures = 1;
			}
		}

		// Specify blocks
		this.PProbeOnEmoCat1 = [];
		for (var i = 0; i < this.nBlocks; i++) {
			if (this.trainingCondition == 0) {
				this.PProbeOnEmoCat1.push(0.5);
			} else if (this.trainingCondition == 1) {
				this.PProbeOnEmoCat1.push(0.5);
			} else if (this.trainingCondition == 2) {
				this.PProbeOnEmoCat1.push(0.5);
			} else if (this.trainingCondition == 3) {
				this.PProbeOnEmoCat1.push(0.1);
			} else if (this.trainingCondition == 4) {
				this.PProbeOnEmoCat1.push(0.9);
			}
		}

		this.xPos = [-0.5, 0, 0.5];
		this.yPos = [-0.33, 0, 0.33];
		this.probeStims = ["<<", ">>"];
		this.nonprobeStims = ["\\/\\/", "/\\/\\"];
		this.locEmoCue;
		this.probeLoc;
		this.probeCat;
		this.nonprobeStimInd;
		this.respKeys.clear();
		this.respKeys = ["F", "J"]; // Note capitalization
		// this.respKeys.shuffle(0, 1); // Don't shuffle for intuitive probes
		if (typeof this.durations0 !== 'undefined') {
			this.durations0.clear();
		}
		this.durations0 = [[300], [100, 200, 400, 600, 1250], [-1], [200], [10]]; // ITI, CSI, respWindow, FB
		this.nStimCat = 2;
		this.nStim = [20, 20];
		this.stimType = ["img", "img"]; // "img", "string"
	};

	//
	// Trial events and functions
	//

	thisTask.trialEventFun.clear();

	// ITI
	thisTask.trialEventFun.push(function() {
		this.caller.emptyCanvas();
		this.caller.showText("+", 0, 0, "white", 32);
		
		var die = Math.random();
		this.locEmoCue = Math.floor(2 * Math.random());
		for (var stimCat = 0; stimCat < 2; stimCat++) {
			this.updateStimIndex(stimCat);
		}
		var die = Math.random();
		if (die < this.PProbeOnEmoCat1[this.iBlock]) {
			this.probeLoc = this.locEmoCue;
		} else {
			this.probeLoc = 1 - this.locEmoCue;
		}
	});

	// Helper function: showPic
	thisTask.showPic = function() {
		this.caller.emptyCanvas();
		
		if (this.showPictures == 0 == 1) {
			return;
		}
		
		for (var loc = 0; loc < 2; loc++) {
			var stimCat;
			if (this.locEmoCue == 0) stimCat = 1 - loc;
			else stimCat = loc;
			var img = this.stimArr[stimCat][this.stimIndexer[stimCat][this.stimIndex[stimCat]]];
			this.trialStims.push(this.stimIndexer[stimCat][this.stimIndex[stimCat]]);
			var w = mycanvas.width / 3.5;
			var h = mycanvas.height / 3.5;
			var l = (mycanvas.width / 2) * (1 + this.xPos[1]) - w / 2;
			var t = (mycanvas.height / 2) * (1 + this.yPos[loc * 2]) - h / 2;
			this.caller.cx.drawImage(img, l, t, w, h);
		}
	};
	
	// Cue
	thisTask.trialEventFun.push(function() {
		this.showPic();
	});

	// Helper function: showProbe
	thisTask.showProbe = function() {
		this.probeLoc12 = 2 * this.probeLoc;
		this.probeCat = Math.floor(Math.random() * 2);
		var probeStim;
		probeStim = this.probeStims[this.probeCat];
		this.caller.showText(probeStim, 0, this.yPos[this.probeLoc12], "white", 32);
		
		this.nonprobeStimInd = Math.floor(Math.random() * this.nonprobeStims.length);
		var nonprobeStim = this.nonprobeStims[this.nonprobeStimInd];
		this.caller.showText(nonprobeStim, 0, this.yPos[2 - this.probeLoc12], "white", 32);
	};

	// Wait for response
	thisTask.trialEventFun.push(function() {
		this.caller.emptyCanvas();
		//thisTask.showPic();
		thisTask.showProbe();
		this.stimTime = Date.now();
	});

	// Feedback
	thisTask.trialEventFun.push(function() {
		this.caller.emptyCanvas();
		if (this.acc == 1) {
			//this.caller.showText("+1", 0, 0, "green", 64);
		} else {
			if (this.RT > 0)
				this.caller.showText("Incorrect!", 0, 0, "red", 64);
			else
				this.caller.showText("Too late!", 0, 0, "red", 64);
		}
	});

	// Empty screen
	thisTask.trialEventFun.push(function() {
		this.caller.emptyCanvas();
	});

	// End of trial
	thisTask.endTrial = function() {
		this.logTrialData();
		this.iTrial++;
	};

	//
	// Task instructions
	//

	thisTask.taskInstr = function() {
		this.caller.emptyCanvas();
		var y = -0.75;
		var str0 = "Indicate whether you see a << or >>";
		this.caller.showText(str0, 0, y, "white");
		y += 0.15;
		var str0 = "For << press " + this.respKeys[0];
		this.caller.showText(str0, 0, y, "white");
		y += 0.15;
		var str0 = "For >> press " + this.respKeys[1];
		this.caller.showText(str0, 0, y, "white");
		y += 0.15;

		this.caller.showText("Press one of the keys to start.", 0, 0.75, "white");
		this.waitToStartTask = 1;
	};

	//
	// Stimuli
	//

	thisTask.imgFilename = function(j, i) {
		var fn0;
		if (j == 0) fn0 = "Stim/" + this.stimSubdir0 + "/stim (" + (i + 1) + ")." + this.stimExt;
		else fn0 = "Stim/" + this.stimSubdir1 + "/stim (" + (i + 1) + ")." + this.stimExt;
		return fn0;
	};

	thisTask.stimArrParamsMaker = function() {
		for (var j = 0; j < this.nStimCat; j++) {
			var subarr = [];
			if (this.stimType[j] == "img") {
				for (var i = 0; i < this.nStim[j]; i++) {
					subarr.push(this.imgFilename(j, i));
				}
			} else if (this.stimType[j] == "string") {
				for (var i = 0; i < this.nStim[j]; i++) {
					subarr.push("W" + j + "_" + i);
				}
			}
			this.stimArrParams.push(subarr);
		}
	}

	//
	// Block code
	//

	// Block specification
	thisTask.nextBlock = function() {
		this.iTrial = 0;
		this.nTrials = this.nTrialsPerBlock;
		this.blockIntro();
	};

	//
	// Response events
	//

	thisTask.respEvents = function() {
		if (this.probeCat == this.respID && this.stimTime > 0)
			this.acc = 1;
		if (this.waitToStartTask == 1) {
			this.waitToStartTask = 0;
			this.nextBlock();
			return;
		}
		if (this.waitToStartBlock == 1) {
			this.waitToStartBlock = 0;
			this.nextTrial();
			return;
		}
		if (this.iTrialStep == 3) {
			clearTimeout(this.currentTimeout);
			this.executeTrialStep();
		}
	};
	
	//
	// Log data
	//

	thisTask.logTrialData = function() {
		if (this.probeLoc == this.locEmoCue) {
			this.probeOnEmoLoc = 1;
		} else {
			this.probeOnEmoLoc = 0;
		}
		this.trialData = {
			taskVariant: this.taskVariant,
			trainingCondition: this.trainingCondition,
			iBlock: this.iBlock,
			blockStartTime: this.blockStartTime,
			stimTime: this.stimTime,
			iTrial: this.iTrial,
			PProbeOnEmoCat1: this.PProbeOnEmoCat1[this.iBlock],
			locEmoCue: this.locEmoCue,
			probeLoc: this.probeLoc,
			probeOnEmoLoc: this.probeOnEmoLoc,
			probeCat: this.probeCat,
			RT: this.RT,
			acc: this.acc, 
			respID: this.respID, 
			trialStims: this.trialStims,
			responses: this.responses,
			trialDurs: this.trialDurs
		};
		this.caller.saveData(this.trialData, this.taskName, this.subjName);
	}
};
