// init with taskArray argument to start.

var generalTaskMachineObj = function() {
	//
	// Variable declarations
	//

	//
	// Task array and next page
	//

	this.taskArray = [];
	this.nextPage;

	// Canvas and stimulus variables
	this.mycanvas;
	this.cx;

	// Active task object variables
	this.activeTask;
	this.taskIndex;

	// AJAX handling
	this.hr;
	this.AJAX_Timeout;
	this.AJAX_timelimit = 1500;
	
	// Misc
	this.subjNr;
	
	// Send data to PHP page for saving: via AJAX
	this.post_via_ajax = function(url, filenameBase, filenameSubject, trialString, taskIndex, numTries) {
		this.hr = new XMLHttpRequest();
		console.log(filenameSubject);
		var vars = "passCode=fakepassword46352&fileNameBase="+filenameBase+"&fileNameSubject="+filenameSubject+"&saveString="+trialString+"&taskIndex="+taskIndex; 
		this.hr.open("POST", url, true);
		this.hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		this.hr.send(vars);
		// Robustness: If no server response within time limit, retry
		var this_ = this;
		this.AJAX_Timeout = setTimeout(function() {
			console.log('Safety limit');
			this_.hr.abort();
			if (numTries < 3) {
				this_.post_via_ajax(url, filenameBase, filenameSubject, trialString, taskIndex, numTries + 1);
			} else {
				alert("Connection error! Please check your internet connection.");
				this_.continueAfterSaving();
			}
		}, this.AJAX_timelimit);
		this.hr.onreadystatechange = function() {
			if (this_.hr.readyState == 4 && this_.hr.status == 200) {
				clearTimeout(this_.AJAX_Timeout);
				this_.continueAfterSaving();
			};	
		};
	};

	this.continueAfterSaving = function() {
		if (this.activeTask.iTrial < this.activeTask.nTrials)
			this.activeTask.nextTrial();
		else
			this.activeTask.endBlock();
	};
	
	//
	// General task helper functions
	//

	this.saveDataBlock(blockData, filenameBase, filenameSubject) {
		let dataString = "";
		for (var iTrial = 0; iTrial < this.BlockData.length; iTrial++) {
			let trialData = this.BlockData[iTrial];
			dataString = dataString + JSON.stringify(trialData) + "\n";
		}
		this.post_via_ajax("savepage.php", filenameBase, filenameSubject, dataString, this.taskIndex, 0);
	}

	this.saveData = function(trialData, filenameBase, filenameSubject) {
		// filenameSubject is subject-input and will be sanitized in PHP
		// create save strings for trialData: array of trial-info objects
		var trialString = JSON.stringify(trialData);
		this.post_via_ajax("savepage.php", filenameBase, filenameSubject, trialString, this.taskIndex, 0);
	};

	this.scaleCanvas = function() {
		var height = window.innerHeight;
		this.mycanvas.height = height * 0.9;
		this.mycanvas.width = height * 0.9;
		//this.showText("Rescaled. Click here and press a key to continue.", 0, 0, 'white', 12);
	};

	this.emptyCanvas = function() {
		this.cx.fillStyle = "black";
		this.cx.fillRect(0, 0, this.mycanvas.width, this.mycanvas.height);
	};

	this.borderCanvas = function() {
		this.cx.fillStyle = "rgb(220, 220, 220)";
		this.cx.fillRect(0, 0, this.mycanvas.width - 0, this.mycanvas.height - 0);
		this.cx.fillStyle = "rgb(220, 220, 220)";
		this.cx.fillRect(10, 10, this.mycanvas.width - 20, this.mycanvas.height - 20);
		this.cx.fillStyle = "black";
		this.cx.fillRect(50, 50, this.mycanvas.width - 100, this.mycanvas.height - 100);
	};

	this.showText = function(text0, x, y, colstr, fontsize, linewidth) {
		if (fontsize == undefined)
			this.cx.font = "16px Georgia";
		else
			this.cx.font = fontsize + "px Georgia";
		if (linewidth == undefined)
			this.cx.lineWidth = 5;
		else
			this.cx.lineWidth = linewidth;
		this.cx.lineJoin = 'circle';
		this.cx.fillStyle = colstr;
		this.cx.textAlign = "center";
		this.cx.textBaseline = "middle";
		this.cx.strokeText(text0, (mycanvas.width / 2) * (1 + x), (mycanvas.height / 2) * (1 + y));
		this.cx.fillText(text0, (mycanvas.width / 2) * (1 + x), (mycanvas.height / 2) * (1 + y));
	};

	//
	// Run task
	//

	this.endTask = function() {
		this.taskIndex++;
		this.runTaskSequence();
	}

	this.startTask = function() {
		this.activeTask.init(this, this.subjNr); // Launch task and provide reference to end-function.
	};

	//
	// Run sequence of tasks
	//

	this.endTaskSequence = function() {
		this.emptyCanvas();
		this.showText("Current task completed, continuing session...", 0, 0, "white");
		window.location = this.nextPage;
	};

	this.runTaskSequence = function() {
		if (this.taskIndex < this.taskArray.length) {
			this.activeTask = this.taskArray[this.taskIndex];
			this.startTask();
		} else {
			this.endTaskSequence();
		}
	};

	//
	// Initialization
	//

	this.init = function(taskArray, nextPage, subjectCode) {
		// Init canvas vars
		this.mycanvas = document.querySelector("#mycanvas");
		this.cx = this.mycanvas.getContext("2d");
		this.scaleCanvas();
		// Get subject number and use for individual random seed
		this.subjNr = subjectCode;
		Math.seedrandom(teg_str2ascsum(this.subjNr));
		// Page to go to after finishing tasks
		this.nextPage = nextPage;
		// Start task list
		this.taskArray = taskArray;
		this.taskIndex = 0;
		this.runTaskSequence();
	};

	//
	// Response listener
	//

	this.respHandler = function(event) {
		event.preventDefault();
		if (this.activeTask != null) {
			this.activeTask.respHandler(event);
		}
	};
	//var _this = this;
	window.addEventListener("keydown", this.respHandler.bind(this));

	this.respHandlerUp = function(event) {
		event.preventDefault();
		if (this.activeTask != null) {
			this.activeTask.respHandlerUp(event);
		}
	};
	//var _this = this;
	window.addEventListener("keyup", this.respHandlerUp.bind(this));

};
